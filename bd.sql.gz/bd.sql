# WordPress MySQL database migration
#
# Generated: Friday 10. April 2015 21:46 UTC
# Hostname: localhost
# Database: `wp_acnew`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-03-23 16:32:08', '2015-03-23 16:32:08', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=475 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/acnew', 'yes'),
(2, 'home', 'http://localhost/acnew', 'yes'),
(3, 'blogname', 'Avenue Code', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'teste@teste.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:21:"polylang/polylang.php";i:1;s:55:"wck-custom-fields-and-custom-post-types-creator/wck.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'acsite', 'yes'),
(42, 'stylesheet', 'acsite', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '30133', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '5', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1428726771;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1428736260;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1428770409;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1428776745;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, 'can_compress_scripts', '0', 'yes'),
(113, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1427128811;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(114, 'current_theme', 'Avenue Code Theme.', 'yes'),
(115, 'theme_mods_acsite', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:14:"header-menu-en";i:2;}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(116, 'theme_switched', '', 'yes'),
(129, 'recently_activated', 'a:0:{}', 'yes'),
(130, 'polylang', 'a:12:{s:7:"browser";i:0;s:7:"rewrite";i:1;s:12:"hide_default";i:0;s:10:"force_lang";i:3;s:13:"redirect_lang";i:0;s:13:"media_support";i:1;s:4:"sync";a:9:{i:0;s:10:"taxonomies";i:1;s:14:"comment_status";i:2;s:12:"sticky_posts";i:3;s:9:"post_date";i:4;s:11:"post_format";i:5;s:11:"post_parent";i:6;s:17:"_wp_page_template";i:7;s:10:"menu_order";i:8;s:13:"_thumbnail_id";}s:10:"post_types";a:0:{}s:10:"taxonomies";a:0:{}s:7:"domains";a:2:{s:2:"en";s:22:"http://localhost/acnew";s:2:"pt";s:25:"http://localhost/acnew.br";}s:7:"version";s:5:"1.7.2";s:12:"default_lang";s:2:"en";}', 'yes'),
(132, 'wck_tools', 'a:1:{i:0;a:4:{s:21:"custom-fields-creator";s:7:"enabled";s:24:"custom-post-type-creator";s:7:"enabled";s:23:"custom-taxonomy-creator";s:8:"disabled";s:37:"swift-templates-and-front-end-posting";s:8:"disabled";}}', 'yes'),
(143, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(208, 'category_children', 'a:0:{}', 'yes'),
(309, 'wck_cptc', 'a:1:{i:0;a:28:{s:9:"post-type";s:16:"clients_partners";s:11:"description";s:0:"";s:14:"singular-label";s:18:"Client and Partner";s:12:"plural-label";s:20:"Clients and Partners";s:12:"hierarchical";s:5:"false";s:11:"has-archive";s:5:"false";s:8:"supports";s:13:"title, editor";s:7:"add-new";s:0:"";s:12:"add-new-item";s:0:"";s:9:"edit-item";s:0:"";s:8:"new-item";s:0:"";s:9:"all-items";s:0:"";s:10:"view-items";s:0:"";s:12:"search-items";s:0:"";s:9:"not-found";s:0:"";s:18:"not-found-in-trash";s:0:"";s:17:"parent-item-colon";s:0:"";s:9:"menu-name";s:0:"";s:6:"public";s:4:"true";s:7:"show-ui";s:4:"true";s:17:"show-in-nav-menus";s:4:"true";s:12:"show-in-menu";s:4:"true";s:13:"menu-position";s:0:"";s:9:"menu-icon";s:0:"";s:15:"capability-type";s:4:"post";s:10:"taxonomies";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite-slug";s:0:"";}}', 'yes'),
(310, 'rewrite_rules', 'a:96:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:44:"clients_partners/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"clients_partners/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"clients_partners/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"clients_partners/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"clients_partners/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"clients_partners/([^/]+)/trackback/?$";s:43:"index.php?clients_partners=$matches[1]&tb=1";s:45:"clients_partners/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?clients_partners=$matches[1]&paged=$matches[2]";s:52:"clients_partners/([^/]+)/comment-page-([0-9]{1,})/?$";s:56:"index.php?clients_partners=$matches[1]&cpage=$matches[2]";s:37:"clients_partners/([^/]+)(/[0-9]+)?/?$";s:55:"index.php?clients_partners=$matches[1]&page=$matches[2]";s:33:"clients_partners/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"clients_partners/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"clients_partners/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"clients_partners/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"clients_partners/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"wck-meta-box/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"wck-meta-box/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"wck-meta-box/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"wck-meta-box/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"wck-meta-box/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"wck-meta-box/([^/]+)/trackback/?$";s:39:"index.php?wck-meta-box=$matches[1]&tb=1";s:41:"wck-meta-box/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?wck-meta-box=$matches[1]&paged=$matches[2]";s:48:"wck-meta-box/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?wck-meta-box=$matches[1]&cpage=$matches[2]";s:33:"wck-meta-box/([^/]+)(/[0-9]+)?/?$";s:51:"index.php?wck-meta-box=$matches[1]&page=$matches[2]";s:29:"wck-meta-box/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"wck-meta-box/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"wck-meta-box/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"wck-meta-box/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"wck-meta-box/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(351, 'informations', 'a:12:{s:11:"facebook_us";s:35:"https://www.facebook.com/avenuecode";s:10:"twitter_us";s:30:"https://twitter.com/AvenueCode";s:13:"googleplus_us";s:37:"https://www.google.com/+AvenuecodeNow";s:11:"linkedin_us";s:44:"https://www.linkedin.com/company/avenue-code";s:10:"youtube_us";s:43:"https://www.youtube.com/user/AvenueCodePlay";s:9:"flickr_us";s:40:"https://www.flickr.com/photos/avenuecode";s:11:"facebook_br";s:0:"";s:10:"twitter_br";s:32:"https://twitter.com/avenuecodebr";s:13:"googleplus_br";s:0:"";s:11:"linkedin_br";s:0:"";s:10:"youtube_br";s:0:"";s:9:"flickr_br";s:0:"";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(4, 5, '_edit_last', '1'),
(5, 5, '_edit_lock', '1427999945:1'),
(6, 7, '_edit_last', '1'),
(7, 7, '_edit_lock', '1427921326:1'),
(8, 8, '_edit_last', '1'),
(9, 8, '_edit_lock', '1427138727:1'),
(10, 9, '_edit_last', '1'),
(11, 9, '_edit_lock', '1427135033:1'),
(12, 13, '_edit_last', '1'),
(13, 13, '_edit_lock', '1427139754:1'),
(14, 14, '_edit_last', '1'),
(15, 14, '_edit_lock', '1427135049:1'),
(16, 17, '_menu_item_type', 'post_type'),
(17, 17, '_menu_item_menu_item_parent', '0'),
(18, 17, '_menu_item_object_id', '5'),
(19, 17, '_menu_item_object', 'page'),
(20, 17, '_menu_item_target', ''),
(21, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(22, 17, '_menu_item_xfn', ''),
(23, 17, '_menu_item_url', ''),
(24, 17, '_menu_item_orphaned', '1427135484'),
(25, 18, '_menu_item_type', 'post_type'),
(26, 18, '_menu_item_menu_item_parent', '0'),
(27, 18, '_menu_item_object_id', '7'),
(28, 18, '_menu_item_object', 'page'),
(29, 18, '_menu_item_target', ''),
(30, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(31, 18, '_menu_item_xfn', ''),
(32, 18, '_menu_item_url', ''),
(33, 18, '_menu_item_orphaned', '1427135484'),
(34, 19, '_menu_item_type', 'post_type'),
(35, 19, '_menu_item_menu_item_parent', '0'),
(36, 19, '_menu_item_object_id', '8'),
(37, 19, '_menu_item_object', 'page'),
(38, 19, '_menu_item_target', ''),
(39, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(40, 19, '_menu_item_xfn', ''),
(41, 19, '_menu_item_url', ''),
(42, 19, '_menu_item_orphaned', '1427135485'),
(43, 20, '_menu_item_type', 'post_type'),
(44, 20, '_menu_item_menu_item_parent', '0'),
(45, 20, '_menu_item_object_id', '14'),
(46, 20, '_menu_item_object', 'page'),
(47, 20, '_menu_item_target', ''),
(48, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 20, '_menu_item_xfn', ''),
(50, 20, '_menu_item_url', ''),
(51, 20, '_menu_item_orphaned', '1427135485'),
(52, 21, '_menu_item_type', 'post_type'),
(53, 21, '_menu_item_menu_item_parent', '0'),
(54, 21, '_menu_item_object_id', '13'),
(55, 21, '_menu_item_object', 'page'),
(56, 21, '_menu_item_target', ''),
(57, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(58, 21, '_menu_item_xfn', ''),
(59, 21, '_menu_item_url', ''),
(60, 21, '_menu_item_orphaned', '1427135486'),
(61, 22, '_menu_item_type', 'post_type'),
(62, 22, '_menu_item_menu_item_parent', '0'),
(63, 22, '_menu_item_object_id', '5'),
(64, 22, '_menu_item_object', 'page'),
(65, 22, '_menu_item_target', ''),
(66, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(67, 22, '_menu_item_xfn', ''),
(68, 22, '_menu_item_url', ''),
(69, 22, '_menu_item_orphaned', '1427135486'),
(70, 23, '_menu_item_type', 'post_type'),
(71, 23, '_menu_item_menu_item_parent', '0'),
(72, 23, '_menu_item_object_id', '9'),
(73, 23, '_menu_item_object', 'page'),
(74, 23, '_menu_item_target', ''),
(75, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(76, 23, '_menu_item_xfn', ''),
(77, 23, '_menu_item_url', ''),
(78, 23, '_menu_item_orphaned', '1427135487'),
(79, 24, '_menu_item_type', 'post_type'),
(80, 24, '_menu_item_menu_item_parent', '0'),
(81, 24, '_menu_item_object_id', '14'),
(82, 24, '_menu_item_object', 'page'),
(83, 24, '_menu_item_target', ''),
(84, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(85, 24, '_menu_item_xfn', ''),
(86, 24, '_menu_item_url', ''),
(88, 25, '_menu_item_type', 'post_type'),
(89, 25, '_menu_item_menu_item_parent', '0'),
(90, 25, '_menu_item_object_id', '13'),
(91, 25, '_menu_item_object', 'page'),
(92, 25, '_menu_item_target', ''),
(93, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(94, 25, '_menu_item_xfn', ''),
(95, 25, '_menu_item_url', ''),
(97, 26, '_menu_item_type', 'post_type'),
(98, 26, '_menu_item_menu_item_parent', '0'),
(99, 26, '_menu_item_object_id', '9'),
(100, 26, '_menu_item_object', 'page'),
(101, 26, '_menu_item_target', ''),
(102, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(103, 26, '_menu_item_xfn', ''),
(104, 26, '_menu_item_url', ''),
(106, 27, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(107, 27, '_menu_item_menu_item_parent', '0'),
(108, 27, '_menu_item_object_id', '8'),
(109, 27, '_menu_item_object', 'page'),
(110, 27, '_menu_item_target', ''),
(111, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(112, 27, '_menu_item_xfn', ''),
(113, 27, '_menu_item_url', ''),
(115, 28, '_menu_item_type', 'post_type'),
(116, 28, '_menu_item_menu_item_parent', '0'),
(117, 28, '_menu_item_object_id', '7'),
(118, 28, '_menu_item_object', 'page'),
(119, 28, '_menu_item_target', ''),
(120, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(121, 28, '_menu_item_xfn', ''),
(122, 28, '_menu_item_url', ''),
(124, 29, '_menu_item_type', 'post_type'),
(125, 29, '_menu_item_menu_item_parent', '0'),
(126, 29, '_menu_item_object_id', '5'),
(127, 29, '_menu_item_object', 'page'),
(128, 29, '_menu_item_target', ''),
(129, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(130, 29, '_menu_item_xfn', ''),
(131, 29, '_menu_item_url', ''),
(133, 30, '_edit_last', '1'),
(134, 30, '_edit_lock', '1427136162:1'),
(135, 30, 'wck_cfc_fields', 'a:1:{i:0;a:8:{s:11:"field-title";s:14:"Carousel Image";s:10:"field-type";s:6:"upload";s:11:"description";s:38:"The resolution must be 1920x810 pixels";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(136, 30, 'wck_cfc_post_type_arg', 'page'),
(137, 30, 'wck_cfc_post_id_arg', '5'),
(138, 30, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:11:"headerimage";s:9:"post-type";s:4:"page";s:8:"repeater";s:4:"true";s:8:"sortable";s:4:"true";s:7:"post-id";s:1:"5";}}'),
(141, 5, 'headerimage', 'a:3:{i:0;a:1:{s:14:"carousel-image";s:2:"85";}i:1;a:1:{s:14:"carousel-image";s:2:"86";}i:2;a:1:{s:14:"carousel-image";s:2:"87";}}'),
(148, 35, '_edit_last', '1'),
(149, 35, '_edit_lock', '1427734328:1'),
(150, 35, 'wck_cfc_fields', 'a:3:{i:0;a:8:{s:11:"field-title";s:5:"Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:8:"Subtitle";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:2;a:8:{s:11:"field-title";s:9:"Body Text";s:10:"field-type";s:14:"wysiwyg editor";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(151, 35, 'wck_cfc_post_type_arg', 'page'),
(152, 35, 'wck_cfc_post_id_arg', '5'),
(153, 35, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:22:"home-avenuecodesection";s:9:"post-type";s:4:"page";s:8:"repeater";s:5:"false";s:8:"sortable";s:5:"false";s:7:"post-id";s:1:"5";}}'),
(154, 5, 'home-avenuecodesection', 'a:1:{i:0;a:3:{s:5:"title";s:11:"AVENUE CODE";s:8:"subtitle";s:0:"";s:9:"body-text";s:325:"<p>With the software innovation journey, the process is just as important as the destination.</p>\r\n\r\n<p>We provide the guidance you need to get there with our IT and management prowess.</p>\r\n\r\n<p>We are DevOps experts. We are mobile technologists. We are a badass team of enterprise consultants and fullstack engineers.</p>\r\n";}}'),
(155, 39, '_edit_last', '1'),
(156, 39, '_edit_lock', '1428526374:1'),
(157, 41, '_edit_last', '1'),
(158, 41, '_edit_lock', '1428527578:1'),
(159, 43, '_edit_last', '1'),
(160, 43, '_edit_lock', '1428528459:1'),
(161, 45, '_edit_last', '1'),
(162, 45, '_edit_lock', '1428611791:1'),
(163, 47, '_edit_last', '1'),
(164, 47, '_edit_lock', '1427838474:1'),
(165, 47, 'wck_cfc_fields', 'a:2:{i:0;a:8:{s:11:"field-title";s:5:"Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:8:"Subtitle";s:10:"field-type";s:14:"wysiwyg editor";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(166, 47, 'wck_cfc_post_type_arg', 'page'),
(167, 47, 'wck_cfc_post_id_arg', '5'),
(168, 47, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:20:"home-portfolioheader";s:9:"post-type";s:4:"page";s:8:"repeater";s:5:"false";s:8:"sortable";s:5:"false";s:7:"post-id";s:1:"5";}}'),
(175, 5, 'home-portfolioheader', 'a:1:{i:0;a:2:{s:5:"title";s:18:"CLIENTS & PARTNERS";s:8:"subtitle";s:278:"<p>&ldquo;I don&rsquo;t see Avenue Code as a mere vendor that provides us with on-demand service. They are our partner.<br />\r\nThey engage in our conversations. They understand our concerns. They really care about our success.&rdquo;<br />\r\n-- SVP of a Fortune 50 Retailer</p>\r\n";}}'),
(180, 5, 'home-portfolio', 'a:11:{i:0;a:5:{s:4:"name";s:6:"Oracle";s:3:"tag";s:7:"partner";s:10:"logo-image";s:2:"51";s:11:"description";s:0:"";s:16:"background-image";s:2:"52";}i:1;a:5:{s:4:"name";s:5:"Lello";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"53";s:11:"description";s:0:"";s:16:"background-image";s:2:"54";}i:2;a:5:{s:4:"name";s:3:"MRV";s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:38:"Largest construction company in Brazil";s:16:"background-image";s:2:"55";}i:3;a:5:{s:4:"name";s:6:"Macy\'s";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"56";s:11:"description";s:45:"Fortune 150 major fashion department retailor";s:16:"background-image";s:2:"57";}i:4;a:5:{s:4:"name";s:7:"Walmart";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"58";s:11:"description";s:0:"";s:16:"background-image";s:2:"59";}i:5;a:5:{s:4:"name";s:3:"GAP";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"60";s:11:"description";s:26:"Fortune 200 major retailer";s:16:"background-image";s:2:"61";}i:6;a:5:{s:4:"name";s:14:"American Eagle";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"62";s:11:"description";s:30:"S&P 400 major apparel retailor";s:16:"background-image";s:2:"63";}i:7;a:5:{s:4:"name";s:15:"Williams Sonoma";s:3:"tag";s:6:"client";s:10:"logo-image";s:2:"64";s:11:"description";s:43:"S&P 400 high-end American consumer retailer";s:16:"background-image";s:2:"65";}i:8;a:5:{s:4:"name";s:3:"BBC";s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:49:"Largest broadcasing station corporation in Europe";s:16:"background-image";s:2:"66";}i:9;a:5:{s:4:"name";s:4:"Sony";s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:37:"Fortune Global 100 Mobile Corporation";s:16:"background-image";s:2:"67";}i:10;a:5:{s:4:"name";s:8:"Karmalot";s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:26:"Mobile App Startup Company";s:16:"background-image";s:2:"68";}}'),
(219, 69, '_edit_last', '1'),
(220, 69, '_edit_lock', '1427925545:1'),
(221, 69, 'wck_cfc_fields', 'a:3:{i:0;a:8:{s:11:"field-title";s:3:"Tag";s:10:"field-type";s:6:"select";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:15:"partner, client";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:11:"Description";s:10:"field-type";s:4:"text";s:11:"description";s:83:"The content of this field will only show up if there is not an image logo uploaded.";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:2;a:8:{s:11:"field-title";s:16:"Background Image";s:10:"field-type";s:6:"upload";s:11:"description";s:37:"The resolution must be 400x300 pixels";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(222, 69, 'wck_cfc_post_type_arg', 'clients_partners'),
(223, 69, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:11:"client_info";s:9:"post-type";s:16:"clients_partners";s:8:"repeater";s:5:"false";s:8:"sortable";s:5:"false";s:7:"post-id";s:0:"";}}'),
(224, 70, '_edit_last', '1'),
(225, 70, '_edit_lock', '1427924238:1'),
(226, 70, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:7:"partner";s:10:"logo-image";s:0:"";s:11:"description";s:20:"Fortune 200 Retailer";s:16:"background-image";s:2:"71";}}'),
(227, 71, '_wp_attached_file', '2015/04/F200Retailer_portfolio_300x400.jpg'),
(228, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:42:"2015/04/F200Retailer_portfolio_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"F200Retailer_portfolio_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"F200Retailer_portfolio_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(229, 73, '_wp_attached_file', '2015/04/william_sonoma_300x400.jpg'),
(230, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:34:"2015/04/william_sonoma_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"william_sonoma_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"william_sonoma_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(231, 72, '_edit_last', '1'),
(232, 72, '_edit_lock', '1427924364:1'),
(233, 72, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:0:"";s:16:"background-image";s:2:"73";}}'),
(234, 74, '_edit_last', '1'),
(235, 74, '_edit_lock', '1427924460:1'),
(236, 75, '_wp_attached_file', '2015/04/F500Retailer_portfolio_300x400.jpg'),
(237, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:42:"2015/04/F500Retailer_portfolio_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"F500Retailer_portfolio_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"F500Retailer_portfolio_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(238, 74, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:20:"Fortune 500 Retailer";s:16:"background-image";s:2:"75";}}'),
(239, 76, '_edit_last', '1'),
(240, 76, '_edit_lock', '1427924533:1'),
(241, 77, '_edit_last', '1'),
(242, 77, '_edit_lock', '1427924584:1'),
(243, 78, '_edit_last', '1'),
(244, 78, '_edit_lock', '1427991025:1'),
(245, 79, '_edit_last', '1'),
(246, 79, '_edit_lock', '1427990871:1'),
(247, 80, '_edit_last', '1'),
(248, 80, '_edit_lock', '1427924626:1'),
(249, 81, '_wp_attached_file', '2015/04/F100Retailer_portfolio_300x400.jpg'),
(250, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:42:"2015/04/F100Retailer_portfolio_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"F100Retailer_portfolio_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"F100Retailer_portfolio_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(251, 76, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:24:"Case Study: Parity issue";s:16:"background-image";s:2:"81";}}'),
(252, 82, '_wp_attached_file', '2015/04/american_eagle_300x400.jpg'),
(253, 82, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:34:"2015/04/american_eagle_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"american_eagle_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"american_eagle_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(254, 77, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:0:"";s:16:"background-image";s:2:"82";}}'),
(255, 83, '_wp_attached_file', '2015/04/F150Retailer_portfolio_300x4001.jpg'),
(256, 83, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:43:"2015/04/F150Retailer_portfolio_300x4001.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"F150Retailer_portfolio_300x4001-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"F150Retailer_portfolio_300x4001-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(257, 78, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:0:"";s:16:"background-image";s:2:"83";}}'),
(258, 84, '_wp_attached_file', '2015/04/walmart_300x400.jpg'),
(259, 84, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:27:"2015/04/walmart_300x400.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"walmart_300x400-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"walmart_300x400-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(260, 79, 'client_info', 'a:1:{i:0;a:4:{s:3:"tag";s:6:"client";s:10:"logo-image";s:0:"";s:11:"description";s:38:"Case Study: Becoming Agile in 6 months";s:16:"background-image";s:2:"84";}}'),
(261, 85, '_wp_attached_file', '2015/03/home-photo.jpg'),
(262, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:810;s:4:"file";s:22:"2015/03/home-photo.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"home-photo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"home-photo-300x127.jpg";s:5:"width";i:300;s:6:"height";i:127;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"home-photo-1024x432.jpg";s:5:"width";i:1024;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(263, 86, '_wp_attached_file', '2015/03/home_landing_SaoPaulo.jpg'),
(264, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:810;s:4:"file";s:33:"2015/03/home_landing_SaoPaulo.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"home_landing_SaoPaulo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"home_landing_SaoPaulo-300x127.jpg";s:5:"width";i:300;s:6:"height";i:127;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"home_landing_SaoPaulo-1024x432.jpg";s:5:"width";i:1024;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(265, 87, '_wp_attached_file', '2015/03/home_landing_BeloHorizonte.jpg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(266, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:810;s:4:"file";s:38:"2015/03/home_landing_BeloHorizonte.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"home_landing_BeloHorizonte-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"home_landing_BeloHorizonte-300x127.jpg";s:5:"width";i:300;s:6:"height";i:127;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:39:"home_landing_BeloHorizonte-1024x432.jpg";s:5:"width";i:1024;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(267, 88, '_edit_last', '1'),
(268, 88, '_edit_lock', '1427999812:1'),
(269, 88, 'wck_cfc_fields', 'a:2:{i:0;a:8:{s:11:"field-title";s:5:"Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:7:"Subtext";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(270, 88, 'wck_cfc_post_type_arg', 'page'),
(271, 88, 'wck_cfc_post_id_arg', '5'),
(272, 88, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:14:"homecovertexts";s:9:"post-type";s:4:"page";s:8:"repeater";s:5:"false";s:8:"sortable";s:5:"false";s:7:"post-id";s:1:"5";}}'),
(273, 5, 'homecovertexts', 'a:1:{i:0;a:2:{s:5:"title";s:33:"SOFTWARE INNOVATION IS A JOURNEY ";s:7:"subtext";s:72:"Let us be your guide. Delivering the world\'s largest ebusiness solutions";}}'),
(274, 89, '_edit_last', '1'),
(275, 89, '_edit_lock', '1428612065:1'),
(276, 89, 'wck_cfc_fields', 'a:3:{i:0;a:8:{s:11:"field-title";s:5:"Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:8:"Subtitle";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:2;a:8:{s:11:"field-title";s:4:"Body";s:10:"field-type";s:14:"wysiwyg editor";s:11:"description";s:0:"";s:8:"required";s:5:"false";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(277, 89, 'wck_cfc_post_type_arg', 'page'),
(278, 89, 'wck_cfc_post_id_arg', '39, 41, 43, 45'),
(279, 89, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:15:"services_header";s:9:"post-type";s:4:"page";s:8:"repeater";s:5:"false";s:8:"sortable";s:5:"false";s:7:"post-id";s:14:"39, 41, 43, 45";}}'),
(280, 90, '_edit_last', '1'),
(281, 90, '_edit_lock', '1428528128:1'),
(282, 90, 'wck_cfc_fields', 'a:4:{i:0;a:8:{s:11:"field-title";s:5:"Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:1;a:8:{s:11:"field-title";s:4:"Body";s:10:"field-type";s:14:"wysiwyg editor";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:2;a:8:{s:11:"field-title";s:5:"Image";s:10:"field-type";s:6:"upload";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}i:3;a:8:{s:11:"field-title";s:10:"Link Title";s:10:"field-type";s:4:"text";s:11:"description";s:0:"";s:8:"required";s:4:"true";s:3:"cpt";s:4:"post";s:13:"default-value";s:0:"";s:7:"options";s:0:"";s:21:"attach-upload-to-post";s:3:"yes";}}'),
(283, 90, 'wck_cfc_post_type_arg', 'page'),
(284, 90, 'wck_cfc_post_id_arg', '39, 41, 43'),
(285, 90, 'wck_cfc_args', 'a:1:{i:0;a:5:{s:9:"meta-name";s:13:"services_body";s:9:"post-type";s:4:"page";s:8:"repeater";s:4:"true";s:8:"sortable";s:4:"true";s:7:"post-id";s:10:"39, 41, 43";}}'),
(286, 39, 'services_header', 'a:1:{i:0;a:2:{s:5:"title";s:21:"Management Consulting";s:8:"subtitle";s:19:"We Show You The Way";}}'),
(287, 91, '_wp_attached_file', '2015/03/omnichannel.jpg'),
(288, 91, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:330;s:6:"height";i:245;s:4:"file";s:23:"2015/03/omnichannel.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"omnichannel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"omnichannel-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(289, 39, 'services_body', 'a:4:{i:0;a:4:{s:5:"title";s:11:"OMNICHANNEL";s:4:"body";s:492:"<p>Omnichannel refers to the state of a firm&#39;s separate channels to market, such as website, mobile, brick and mortar stores. They become integrated and provide a seamless experience to the end user. The consumer gets a consistent experience from a retailer whichever channel they are using. To become truly omnichannel, a firm should not only have a strategy to manage Big Data in an IT organization, but also have an associated plan for marketing, business process, and execution.</p>\n\n";s:5:"image";s:2:"91";s:10:"link-title";s:11:"Omnichannel";}i:1;a:4:{s:5:"title";s:27:"TECH ORGANIZATION STRUCTURE";s:4:"body";s:1244:"<p style="line-height: 20.7999992370605px;">e help companies restructure their organization to optimize their business and software development process. Here is the list of services we offer:</p>\n\n<table style="line-height: 20.7999992370605px; width: 750px;">\n	<tbody>\n		<tr>\n			<td style="vertical-align: baseline; width: 375px;">- Value Stream Mapping</td>\n			<td style="vertical-align: baseline; width: 375px;">- Process Re-engineering</td>\n		</tr>\n		<tr>\n			<td style="vertical-align: baseline; width: 375px;">- Flatten the Tech Organization</td>\n			<td style="vertical-align: baseline; width: 375px;">- Ideation Process</td>\n		</tr>\n		<tr>\n			<td style="vertical-align: baseline; width: 375px;">- Refined Metrics Reporting Structure</td>\n			<td style="vertical-align: baseline; width: 375px;">- One click Integration</td>\n		</tr>\n		<tr>\n			<td style="vertical-align: baseline; width: 375px;">- Optimized Distributed Developments</td>\n			<td style="vertical-align: baseline; width: 375px;">- Continuous Integration</td>\n		</tr>\n		<tr>\n			<td style="vertical-align: baseline; width: 375px;">- Empowerment of All Team Members</td>\n			<td style="vertical-align: baseline; width: 375px;">- Continuous Deployment</td>\n		</tr>\n	</tbody>\n</table>\n";s:5:"image";s:2:"92";s:10:"link-title";s:27:"Tech Organization Structure";}i:2;a:4:{s:5:"title";s:30:"TECHNOLOGY SPENDING AND BUDGET";s:4:"body";s:723:"<p><span style="line-height: 20.7999992370605px;">We work with IT organizations to save millions of dollars on software development.</span><br style="line-height: 20.7999992370605px;" />\n<br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Optimizing technology budgets by leveraging hybrid in-house and outsourced workforce</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Optimized distributed model</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Helping with the &quot;Build vs. Buy&quot; decision, by providing alternatives to doing everything in-house.</span></p>\n";s:5:"image";s:2:"93";s:10:"link-title";s:30:"Technology Spending and Budget";}i:3;a:4:{s:5:"title";s:20:"PROCESS AND WORKFLOW";s:4:"body";s:857:"<p><span style="line-height: 20.7999992370605px;">- Agile transformation for a large IT organization</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Agile framework vs. waterfall</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Ideation process</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Product management process</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Continous integration</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Continuous delivery</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Governance</span></p>\n";s:5:"image";s:2:"94";s:10:"link-title";s:20:"Process and Workflow";}}'),
(290, 92, '_wp_attached_file', '2015/03/tech_organization.jpg'),
(291, 92, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:327;s:6:"height";i:243;s:4:"file";s:29:"2015/03/tech_organization.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"tech_organization-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"tech_organization-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(292, 93, '_wp_attached_file', '2015/03/technology.jpg'),
(293, 93, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:328;s:6:"height";i:244;s:4:"file";s:22:"2015/03/technology.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"technology-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"technology-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(294, 94, '_wp_attached_file', '2015/03/process.jpg'),
(295, 94, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:327;s:6:"height";i:243;s:4:"file";s:19:"2015/03/process.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"process-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"process-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(296, 95, '_wp_attached_file', '2015/03/light_house.png'),
(297, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:282;s:6:"height";i:282;s:4:"file";s:23:"2015/03/light_house.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"light_house-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(298, 39, '_thumbnail_id', '95'),
(299, 41, 'services_header', 'a:1:{i:0;a:2:{s:5:"title";s:36:"Project Ownership and Implementation";s:8:"subtitle";s:21:"We help you get there";}}'),
(300, 98, '_wp_attached_file', '2015/03/services_program_and_project.jpg'),
(301, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:328;s:6:"height";i:243;s:4:"file";s:40:"2015/03/services_program_and_project.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"services_program_and_project-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:40:"services_program_and_project-300x222.jpg";s:5:"width";i:300;s:6:"height";i:222;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(302, 99, '_wp_attached_file', '2015/03/services_product_management.jpg'),
(303, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:326;s:6:"height";i:243;s:4:"file";s:39:"2015/03/services_product_management.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"services_product_management-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:39:"services_product_management-300x224.jpg";s:5:"width";i:300;s:6:"height";i:224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(304, 41, 'services_body', 'a:5:{i:0;a:4:{s:5:"title";s:30:"PROGRAM AND PROJECT MANAGEMENT";s:4:"body";s:418:"<p style="line-height: 20.7999992370605px;">From medium to large projects, our consultants participate in the process of planning, execution, evaluation, or all of the above. Some prior projects include</p>\n\n<p style="line-height: 20.7999992370605px;">- Omnichannel implementations<br />\n- 20+MM ecommerce website project<br />\n- Mobile development project<br />\n- POS systems<br />\n- Warehouse management systems</p>\n";s:5:"image";s:2:"98";s:10:"link-title";s:18:"Product Management";}i:1;a:4:{s:5:"title";s:18:"PRODUCT MANAGEMENT";s:4:"body";s:728:"<p style="line-height: 20.7999992370605px;">Product management as a role is often overlooked in a technical environment. However, PMs are the lifeblood to any organization striving to achieve superiority in the digital world. Avenue Code helps clients both build and improve their product superiority by creating and maintaining a strong product management organization that can:</p>\n\n<p style="line-height: 20.7999992370605px;">- Go in a straight line from idea to functioning software<br />\n- Establish the practice of user story writing<br />\n- Define and implement the role of a product owner<br />\n- Implement triage methods for business and technology opportunities<br />\n- Create successful product management groups</p>\n";s:5:"image";s:2:"99";s:10:"link-title";s:18:"Product Management";}i:2;a:4:{s:5:"title";s:19:"END-TO-END DELIVERY";s:4:"body";s:283:"<p><span style="line-height: 20.7999992370605px;">Fully outsourced projects including ideation, productization, project management, design, creation, and all facets of technology developments. Avenue Code has been handling end-to-end projects delivery since its inception</span></p>\n";s:5:"image";s:3:"100";s:10:"link-title";s:19:"End To End Delivery";}i:3;a:4:{s:5:"title";s:24:"PROOF OF CONCEPTS/PILOTS";s:4:"body";s:302:"<p><span style="line-height: 20.7999992370605px;">- Achieve Minimum Viable Product through intelligent proofing/scrubbing of concepts</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Create a pilot team structure using the Lean approach</span></p>\n";s:5:"image";s:3:"101";s:10:"link-title";s:24:"Proof of Concepts/Pilots";}i:4;a:4:{s:5:"title";s:73:"AGILE SOFTWARE DEVELOPMENT LIFE CYCLE – ECOMMERCE, MOBILE, TABLETS, POS";s:4:"body";s:995:"<p><span style="line-height: 20.7999992370605px;">- End-to-end delivery of Agile SDLC</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Staff augmentation of Agile professionals</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Agile engineering professionals</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Project management</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Scrum masters</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Product management</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Emergence training and coaching</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Classroom training</span></p>\n";s:5:"image";s:3:"102";s:10:"link-title";s:37:"Agile Software Development Life Cycle";}}'),
(305, 100, '_wp_attached_file', '2015/03/services_end_to_end.jpg'),
(306, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:323;s:6:"height";i:240;s:4:"file";s:31:"2015/03/services_end_to_end.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"services_end_to_end-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"services_end_to_end-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(307, 101, '_wp_attached_file', '2015/03/services_proof_of_concept.jpg'),
(308, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:327;s:6:"height";i:243;s:4:"file";s:37:"2015/03/services_proof_of_concept.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"services_proof_of_concept-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"services_proof_of_concept-300x223.jpg";s:5:"width";i:300;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(309, 102, '_wp_attached_file', '2015/03/services_agile.jpg'),
(310, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:330;s:6:"height";i:246;s:4:"file";s:26:"2015/03/services_agile.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"services_agile-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"services_agile-300x224.jpg";s:5:"width";i:300;s:6:"height";i:224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(311, 103, '_wp_attached_file', '2015/03/services_engineering_professionals.jpg'),
(312, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:240;s:4:"file";s:46:"2015/03/services_engineering_professionals.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:46:"services_engineering_professionals-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:46:"services_engineering_professionals-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(313, 43, 'services_body', 'a:2:{i:0;a:4:{s:5:"title";s:25:"ENGINEERING PROFESSIONALS";s:4:"body";s:815:"<p><span style="line-height: 20.7999992370605px;">- eCommerce architects</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Software Development (Java, Ruby, Big Data)</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Continuous Integration</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- QE-Automation</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- UX/UI</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Mobile (iOS, Android)</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- ATG</span></p>\n";s:5:"image";s:3:"103";s:10:"link-title";s:25:"Engineering Professionals";}i:1;a:4:{s:5:"title";s:19:"AGILE PROFESSIONALS";s:4:"body";s:479:"<p><span style="line-height: 20.7999992370605px;">- Program/Project Managers</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Product Managers</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Scrum Masters/Iteration Managers</span><br style="line-height: 20.7999992370605px;" />\n<span style="line-height: 20.7999992370605px;">- Business &amp; Systems Analysts</span></p>\n";s:5:"image";s:3:"104";s:10:"link-title";s:19:"Agile Professionals";}}'),
(314, 104, '_wp_attached_file', '2015/03/services_agile_professionals.jpg'),
(315, 104, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:360;s:6:"height";i:240;s:4:"file";s:40:"2015/03/services_agile_professionals.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"services_agile_professionals-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:40:"services_agile_professionals-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(316, 43, 'services_header', 'a:1:{i:0;a:3:{s:5:"title";s:35:"Engineering and Agile Professionals";s:8:"subtitle";s:26:"Our People Are World Class";s:4:"body";s:701:"<p><span style="line-height: 20.7999992370605px;">We choose our consultants to meet our client&rsquo;s requirements. We are not a typical staffing company that provides resources without considering how they will best help solve our client&rsquo;s problem. Avenue Code is a strategic partner with our clients, and we support their best interests. All of our consultants are our employees, so we care about their success on client sites and their professional growth as much as we care about your project and product. Our rigorous three-round-interview process sets a high bar on who represents Avenue Code. You receive world-class consultancy with our engineering and agile professionals.</span></p>\r\n";}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-03-23 16:32:08', '2015-03-23 16:32:08', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-03-23 16:32:08', '2015-03-23 16:32:08', '', 0, 'http://localhost/acnew/?p=1', 0, 'post', '', 1),
(5, 1, '2015-03-23 18:25:50', '2015-03-23 18:25:50', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-04-02 18:39:05', '2015-04-02 18:39:05', '', 0, 'http://localhost/acnew/?page_id=5', 0, 'page', '', 0),
(6, 1, '2015-03-23 18:25:50', '2015-03-23 18:25:50', '', 'Home', '', 'inherit', 'open', 'open', '', '5-revision-v1', '', '', '2015-03-23 18:25:50', '2015-03-23 18:25:50', '', 5, 'http://localhost/acnew/?p=6', 0, 'revision', '', 0),
(7, 1, '2015-03-23 18:25:57', '2015-03-23 18:25:57', '', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2015-03-23 18:25:57', '2015-03-23 18:25:57', '', 0, 'http://localhost/acnew/?page_id=7', 0, 'page', '', 0),
(8, 1, '2015-03-23 18:26:07', '2015-03-23 18:26:07', '', 'Careers', '', 'publish', 'open', 'open', '', 'careers', '', '', '2015-03-23 18:26:07', '2015-03-23 18:26:07', '', 0, 'http://localhost/acnew/?page_id=8', 0, 'page', '', 0),
(9, 1, '2015-03-23 18:26:10', '2015-03-23 18:26:10', '', 'Services', '', 'publish', 'open', 'open', '', 'services', '', '', '2015-03-23 18:26:10', '2015-03-23 18:26:10', '', 0, 'http://localhost/acnew/?page_id=9', 0, 'page', '', 0),
(10, 1, '2015-03-23 18:25:57', '2015-03-23 18:25:57', '', 'About', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-03-23 18:25:57', '2015-03-23 18:25:57', '', 7, 'http://localhost/acnew/?p=10', 0, 'revision', '', 0),
(11, 1, '2015-03-23 18:26:07', '2015-03-23 18:26:07', '', 'Careers', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2015-03-23 18:26:07', '2015-03-23 18:26:07', '', 8, 'http://localhost/acnew/?p=11', 0, 'revision', '', 0),
(12, 1, '2015-03-23 18:26:10', '2015-03-23 18:26:10', '', 'Services', '', 'inherit', 'open', 'open', '', '9-revision-v1', '', '', '2015-03-23 18:26:10', '2015-03-23 18:26:10', '', 9, 'http://localhost/acnew/?p=12', 0, 'revision', '', 0),
(13, 1, '2015-03-23 18:26:24', '2015-03-23 18:26:24', '', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2015-03-23 18:26:24', '2015-03-23 18:26:24', '', 0, 'http://localhost/acnew/?page_id=13', 0, 'page', '', 0),
(14, 1, '2015-03-23 18:26:30', '2015-03-23 18:26:30', '', 'Code Highway', '', 'publish', 'open', 'open', '', 'code-highway', '', '', '2015-03-23 18:26:30', '2015-03-23 18:26:30', '', 0, 'http://localhost/acnew/?page_id=14', 0, 'page', '', 0),
(15, 1, '2015-03-23 18:26:24', '2015-03-23 18:26:24', '', 'Contact', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2015-03-23 18:26:24', '2015-03-23 18:26:24', '', 13, 'http://localhost/acnew/?p=15', 0, 'revision', '', 0),
(16, 1, '2015-03-23 18:26:30', '2015-03-23 18:26:30', '', 'Code Highway', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2015-03-23 18:26:30', '2015-03-23 18:26:30', '', 14, 'http://localhost/acnew/?p=16', 0, 'revision', '', 0),
(17, 1, '2015-03-23 18:31:23', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:23', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=17', 1, 'nav_menu_item', '', 0),
(18, 1, '2015-03-23 18:31:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=18', 1, 'nav_menu_item', '', 0),
(19, 1, '2015-03-23 18:31:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2015-03-23 18:31:25', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2015-03-23 18:31:25', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=21', 1, 'nav_menu_item', '', 0),
(22, 1, '2015-03-23 18:31:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2015-03-23 18:31:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2015-03-23 18:31:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2015-03-23 18:34:18', '2015-03-23 18:34:18', ' ', '', '', 'publish', 'open', 'open', '', '24', '', '', '2015-03-23 18:34:18', '2015-03-23 18:34:18', '', 0, 'http://localhost/acnew/?p=24', 6, 'nav_menu_item', '', 0),
(25, 1, '2015-03-23 18:34:17', '2015-03-23 18:34:17', ' ', '', '', 'publish', 'open', 'open', '', '25', '', '', '2015-03-23 18:34:17', '2015-03-23 18:34:17', '', 0, 'http://localhost/acnew/?p=25', 5, 'nav_menu_item', '', 0),
(26, 1, '2015-03-23 18:34:17', '2015-03-23 18:34:17', ' ', '', '', 'publish', 'open', 'open', '', '26', '', '', '2015-03-23 18:34:17', '2015-03-23 18:34:17', '', 0, 'http://localhost/acnew/?p=26', 4, 'nav_menu_item', '', 0),
(27, 1, '2015-03-23 18:34:17', '2015-03-23 18:34:17', ' ', '', '', 'publish', 'open', 'open', '', '27', '', '', '2015-03-23 18:34:17', '2015-03-23 18:34:17', '', 0, 'http://localhost/acnew/?p=27', 3, 'nav_menu_item', '', 0),
(28, 1, '2015-03-23 18:34:17', '2015-03-23 18:34:17', ' ', '', '', 'publish', 'open', 'open', '', '28', '', '', '2015-03-23 18:34:17', '2015-03-23 18:34:17', '', 0, 'http://localhost/acnew/?p=28', 2, 'nav_menu_item', '', 0),
(29, 1, '2015-03-23 18:34:17', '2015-03-23 18:34:17', ' ', '', '', 'publish', 'open', 'open', '', '29', '', '', '2015-03-23 18:34:17', '2015-03-23 18:34:17', '', 0, 'http://localhost/acnew/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2015-03-23 18:42:42', '2015-03-23 18:42:42', '', 'Header Images', '', 'publish', 'closed', 'closed', '', 'header-images', '', '', '2015-03-23 18:42:42', '2015-03-23 18:42:42', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=30', 0, 'wck-meta-box', '', 0),
(35, 1, '2015-03-26 21:56:41', '2015-03-26 21:56:41', '', 'Home - Avenue Code Section', '', 'publish', 'closed', 'closed', '', 'home-avenue-code-section', '', '', '2015-03-26 21:56:41', '2015-03-26 21:56:41', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=35', 0, 'wck-meta-box', '', 0),
(36, 1, '2015-03-30 17:44:16', '2015-03-30 17:44:16', 'a:1:{i:0;a:2:{i:0;s:0:"";i:1;s:0:"";}}', 'polylang_mo_3', '', 'publish', 'open', 'open', '', 'polylang_mo_3', '', '', '2015-03-30 17:44:16', '2015-03-30 17:44:16', '', 0, 'http://localhost/acnew/?post_type=polylang_mo&p=36', 0, 'polylang_mo', '', 0),
(37, 1, '2015-03-30 17:44:25', '2015-03-30 17:44:25', 'a:1:{i:0;a:2:{i:0;s:0:"";i:1;s:0:"";}}', 'polylang_mo_6', '', 'publish', 'open', 'open', '', 'polylang_mo_6', '', '', '2015-03-30 17:44:25', '2015-03-30 17:44:25', '', 0, 'http://localhost/acnew/?post_type=polylang_mo&p=37', 0, 'polylang_mo', '', 0),
(39, 1, '2015-03-31 21:39:22', '2015-03-31 21:39:22', '', 'Management Consulting', '', 'publish', 'open', 'open', '', 'management-consulting', '', '', '2015-04-08 20:52:50', '2015-04-08 20:52:50', '', 9, 'http://localhost/acnew/?page_id=39', 0, 'page', '', 0),
(40, 1, '2015-03-31 21:39:22', '2015-03-31 21:39:22', '', 'Management Consulting', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2015-03-31 21:39:22', '2015-03-31 21:39:22', '', 39, 'http://localhost/acnew/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2015-03-31 21:39:39', '2015-03-31 21:39:39', '', 'Project Ownership and Implementation', '', 'publish', 'open', 'open', '', 'project-ownership-and-implementation', '', '', '2015-04-08 21:13:44', '2015-04-08 21:13:44', '', 9, 'http://localhost/acnew/?page_id=41', 0, 'page', '', 0),
(42, 1, '2015-03-31 21:39:39', '2015-03-31 21:39:39', '', 'Project Ownership and Implementation', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2015-03-31 21:39:39', '2015-03-31 21:39:39', '', 41, 'http://localhost/acnew/41-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2015-03-31 21:39:52', '2015-03-31 21:39:52', '', 'Engineering and Agile Professionals', '', 'publish', 'open', 'open', '', 'engineering-and-agile-professionals', '', '', '2015-04-08 21:27:39', '2015-04-08 21:27:39', '', 9, 'http://localhost/acnew/?page_id=43', 0, 'page', '', 0),
(44, 1, '2015-03-31 21:39:52', '2015-03-31 21:39:52', '', 'Engineering and Agile Professionals', '', 'inherit', 'open', 'open', '', '43-revision-v1', '', '', '2015-03-31 21:39:52', '2015-03-31 21:39:52', '', 43, 'http://localhost/acnew/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2015-03-31 21:40:04', '2015-03-31 21:40:04', '', 'Avenue Code Academy', '', 'publish', 'open', 'open', '', 'avenue-code-academy', '', '', '2015-03-31 21:40:04', '2015-03-31 21:40:04', '', 9, 'http://localhost/acnew/?page_id=45', 0, 'page', '', 0),
(46, 1, '2015-03-31 21:40:04', '2015-03-31 21:40:04', '', 'Avenue Code Academy', '', 'inherit', 'open', 'open', '', '45-revision-v1', '', '', '2015-03-31 21:40:04', '2015-03-31 21:40:04', '', 45, 'http://localhost/acnew/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2015-03-31 21:50:12', '2015-03-31 21:50:12', '', 'Home - Portfolio Header', '', 'publish', 'closed', 'closed', '', 'home-portfolio-header', '', '', '2015-03-31 21:50:12', '2015-03-31 21:50:12', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=47', 0, 'wck-meta-box', '', 0),
(69, 1, '2015-04-01 21:35:58', '2015-04-01 21:35:58', '', 'Clients and Partners', '', 'publish', 'closed', 'closed', '', 'clients-and-partners', '', '', '2015-04-01 21:59:05', '2015-04-01 21:59:05', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=69', 0, 'wck-meta-box', '', 0),
(70, 1, '2015-04-01 21:37:54', '2015-04-01 21:37:54', '<a href="http://avenuecode.com/wp-content/uploads/2014/12/Case-Study-graphic-2.png"><img class="wp-image-713 size-medium" src="http://avenuecode.com/wp-content/uploads/2014/12/Case-Study-graphic-2-200x300.png" alt="Continuous integration was a win for Gap" width="200" height="300" /></a>\r\n<h2>Key Facts</h2>\r\n<b>Locations: </b>America HQ – stores worldwide\r\n\r\n<b>Industry: </b>Retail\r\n\r\n<b># engineers supported: </b>600\r\n\r\n<strong>The Word</strong>\r\n<blockquote><span style="color: #222222;">For several years, the store systems team were only able to deliver 3 major software releases per year across the company\'s fleet of 3,000 stores around the world. Upon adopting our Continuous Delivery strategy, the team was able to increase release frequency to 8 times per year and continues to increase frequency and speed of releases year over year.  Last year, we successfully executed 14 releases and the next target is releasing every 2 weeks, which means that new features and functions will be made available to store associates and customers more than 24 times per year. Jaclyn, the release manager, was instrumental in implementing our Continuous Delivery strategy. She quickly leveraged her relationship building skills to engage and influence stakeholders within store systems and across he IT organization and she drew from her Lean Six Sigma experience in order to implement a structured, data-driven continuous improvement process that has enabled the team to get better with each release. </span></blockquote>\r\n&nbsp;\r\n<h2><b>Challenge</b></h2>\r\nCreating cutting-edge software is simply not enough in the competitive retail market today. Success is driven by being able to deliver new functionality continuously and rapidly. Our client had a goal for its 2,000+ stores to release software in shorter cycles, but their current process for validation and releasing software to their stores was both inefficient and ineffective. Before we stepped in to guide them, they were already struggling with just four releases per year. With our help, they were able to close their development delivery “gap.” After we were brought on board, we found their key bottlenecks to be a lack of synchronization across projects, inefficient process for integrated testing environments, and low accountability by project teams. After digging a bit deeper into their organization, this is what we discovered:\r\n<ul>\r\n	<li><b>No Schedule</b></li>\r\n</ul>\r\nAn enterprise level release calendar was not in place. Each and every project team (up to 12 at a time) followed its own project level release schedule. The lack of an enterprise release cadence failed to provide structure and due dates for collaboration to resolve failed tests. In turn, the problem was amplified due to duplicate efforts since teams were not collaborating and resolving issues in isolated environments.\r\n<ul>\r\n	<li><b>Unstable Testing Environment</b></li>\r\n</ul>\r\nUnstable environments and ineffective processes for integration testing caused waste and complexity. End-to-end workflow testing occurred too late in the cycle, which delayed the detection of defects. The "early and often" testing guideline was also non-existent. We firmly believe resolving this issue is done by including integration testing at a team level and clarifying the team’s ‘Definition of Done.’ However, they were not familiar with any of these practices. We also found their state of integration testing process was labor intensive because the end-to-end workflow testing was entirely manual. Consequently, the release management team was unable to act proactively to manage the impacts on interdependent projects in the pipeline.\r\n<ul>\r\n	<li><b>Accountability</b></li>\r\n</ul>\r\nSince integration testing was not a part of project level ‘Definition of Done,’ project teams were dependent on release management to identify failures and defects during release testing.  The release team would discover defects and the root causes in order to submit the change to the project teams for code fixes.  Accountability for code quality was displaced to the release team instead of the project team.  The current state of accountability of testing with the release team caused a high level of waste.  Debugging was more complicated given the number of simultaneous changes from the multiple projects.\r\n\r\n&nbsp;\r\n<h2><b>Solution</b></h2>\r\nWe decided to start by making an initial assessment of the process using the Lean practice of Value Stream Mapping (VSM). Current and future end-to-end workflow mapping provided us visibility into activities that produced waste, additional costs, and were valueless to the customer. We made a deeper analysis using a Lean Six Sigma technique DMAIC (Define, Measure, Analyze, Improve and Control) to reduce the gaps. The outcome was an alignment to the enterprise iteration length of ten business days for each release testing cycle, with a 90% end-to-end pass rate for all projects. The client chose a team of workgroups to implement the following improvements:\r\n\r\n&nbsp;\r\n\r\n<b>Create a standard release schedule to be followed for all projects</b>\r\n\r\nThe first step to encourage its adoption was the identification of stakeholders from development, testing, and deployment. They gathered activity durations and consolidated them into one release schedule. The first attempt was successfully deployed in 6 weeks.\r\n\r\n&nbsp;\r\n\r\n<b>Design and build an integrated testing environment</b>\r\n\r\nMost of the efforts to design an integrated testing environment already existed.  What the client lacked was a leader to evangelize the concept and get buy-in from all of the necessary project teams. Once that was achieved, the majority of the remaining effort was dedicated to the orchestration of middleware teams for configurations and data upgrades. As greater transparency was adopted, a win-win situation emerged. Both the business stakeholders and the release management team began to enjoy the benefits of the newly integrated testing environment within two months.\r\n\r\n&nbsp;\r\n\r\n<b>Emphasize project level ownership for pipeline test cases</b>\r\n\r\nThe release team began to communicate the new expectations, but the release schedule still wasn’t set. Once it was, the release package deployed on time and according to schedule. Code that was ‘Ready’ went to production. Teams would either make the release, or subscribe to the next release. To facilitate this change, we created a series of regular events such as release level daily stand-ups, regular announcements, and retrospectives. In just three months, project teams demonstrated greater ownership, and release management staff transferred efforts from testing, to oversight and coordination of testing by reducing the number of test cases fixed.\r\n\r\n&nbsp;\r\n<h2><b>Results</b></h2>\r\n<ul>\r\n	<li>Total cost savings of $1 million</li>\r\n	<li>Software is now released to production 26 times a year - an increase of 22x or 550%</li>\r\n	<li>The client\'s release management cost per project went down 75% in 2.5 years</li>\r\n	<li>The number of test cases needing to be fixed by the release team decreased from 144 to 12</li>\r\n</ul>', 'Fortune 200 Retailer', '', 'publish', 'closed', 'closed', '', '70', '', '', '2015-04-01 21:39:39', '2015-04-01 21:39:39', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=70', 0, 'clients_partners', '', 0),
(71, 1, '2015-04-01 21:39:36', '2015-04-01 21:39:36', '', 'F200Retailer_portfolio_300x400', '', 'inherit', 'open', 'open', '', 'f200retailer_portfolio_300x400', '', '', '2015-04-01 21:39:36', '2015-04-01 21:39:36', '', 70, 'http://localhost/acnew/wp-content/uploads/2015/04/F200Retailer_portfolio_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2015-04-01 21:41:44', '2015-04-01 21:41:44', '', 'Williams Sonoma', '', 'publish', 'closed', 'closed', '', 'williams-sonoma', '', '', '2015-04-01 21:41:44', '2015-04-01 21:41:44', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=72', 0, 'clients_partners', '', 0),
(73, 1, '2015-04-01 21:41:37', '2015-04-01 21:41:37', '', 'william_sonoma_300x400', '', 'inherit', 'open', 'open', '', 'william_sonoma_300x400', '', '', '2015-04-01 21:41:37', '2015-04-01 21:41:37', '', 72, 'http://localhost/acnew/wp-content/uploads/2015/04/william_sonoma_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2015-04-01 21:42:50', '2015-04-01 21:42:50', '<h2>Key Facts</h2>\r\n<b>Locations: </b>America HQ – Stores Worldwide\r\n\r\n<b>Industry: </b>Retail\r\n\r\n<b># engineers supported: </b>20\r\n\r\n&nbsp;\r\n\r\n<b>The Word</b>\r\n<blockquote>There is a perception that Agile teams don’t plan but they do all the time. Now, changes are no longer negative - Client Product Manager</blockquote>\r\n<h2></h2>\r\n<h2><b>The Challenge</b></h2>\r\nSuccess depended on a faster, nimbler implementation for their Asia Expansion Program in Japan - their competitors were moving to corner the market. Time to market was crucial, as the program was in the final wave and the timeline had been tight and set. In order for this to be successful, alignment between the “leading California fast fashion retailer” and a third project needed to work harmoniously in the same application area. The problem wasn’t just to stand up a new brand in a new market, it was also working simultaneously with two other teams in the same application area (a.k.a one code base). Stores all over the world operated on a point-of-sale system that was over seventeen years old, which posed an even greater hurdle since the teams were not dealing with state-of-the-art software, but old systems with high levels of constraints. Lastly, they needed to factor in the addition of new tenders (forms of payment) to support the opening of this store type. This was a huge hurdle, because the Japanese market has very specific requirements due to their shopping culture and regulations. Throughout it all, we kept focused on the two most important questions:\r\n<ol>\r\n	<li>Are we building the right product? [Business Facing]</li>\r\n	<li>Are we building the product right? [Technology Facing]</li>\r\n</ol>\r\n<h2></h2>\r\n<h2><b>The Solution</b></h2>\r\nThe POS work that the team completed helped our client support their other in-country brands. This provided a viable POS platform for planned growth, as new brands require a POS that can be localized and implemented quickly and at lower cost. We made sure to leverage assets they had previously wherever possible to increase speed, reduce cost, and complexity. All the while, we balanced the needs of their other in country brand when creating new interfaces that also worked well with the available system capabilities. To guard against over-riding each other in the code base, we coordinated story play (interplay and away stories) to increase productivity between teams and manage dependencies. Additionally, there were competing frameworks in the same project enterprise [Agile and Waterfall]. The business teams which had input for the application testing were using waterfall. The business teams weren’t ready, nor had the available resources, to support the level of needs from our client. Without test data we were at a stand still; mocking data only got us so far. Using agile meant we needed test data for every sprint and every release. After a few hiccups, the business hired a resource to exclusively work with the agile application teams. We had found a way to work together. Lastly, we implemented a Scrum of Scrum meeting to provide transparency between teams regarding dependencies of deployment. This was the final tool that fueled the teams to high productivity. The most impactful improvements were created in the following areas:\r\n\r\n<b>Collaboration Amongst Project Teams</b>\r\n\r\nWe improved coordination and alignment by increasing transparency of work…where, how, and when. This allowed the teams to respond to broken builds more effectively and efficiently, avoid rework occurring due to the lack of understanding in the shared code base, and manage dependencies.\r\n\r\n<b>Continuous Integration Environment </b>A new continuous integration environment was employed for this program. This took the place of the previous VM configurations, which caused unforeseen and lengthy delays. This new environment also decrease the time to troubleshoot broken builds by leveraging it’s inherent tools.\r\n\r\n<b>Complete Agile Transformation</b>\r\n\r\nWe helped their teams adopt Enterprise Level Rules for Agile Software Development including two very important best practices:  1) Definition of Ready and 2) Definition of Done. Definition of Ready kept teams focused on work that was ready to be coded.  This decreased down time, wait time, and rework.  Definition of Done kept teams from delivering unfinished and incomplete code. This fueled the shortening of testing time.\r\n\r\n<b>External Team Coordination </b>We provided the coordination between Agile and Waterfall teams regarding the alignment of key timelines and activities. Prior to this, commitments were not being met and work was wasteful.\r\n<h2></h2>\r\n<h3><b>Results</b></h3>\r\n<ul>\r\n	<li>30% faster delivery to market generated $6.5 million in revenue</li>\r\n	<li>New brand &amp; geographic market in less than 8 months in Japan</li>\r\n	<li>3 subsequent releases within 3 months for the full application suite</li>\r\n</ul>', 'Fortune 500 Retailer', '', 'publish', 'closed', 'closed', '', 'fortune-500-retailer', '', '', '2015-04-01 21:42:50', '2015-04-01 21:42:50', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=74', 0, 'clients_partners', '', 0),
(75, 1, '2015-04-01 21:42:48', '2015-04-01 21:42:48', '', 'F500Retailer_portfolio_300x400', '', 'inherit', 'open', 'open', '', 'f500retailer_portfolio_300x400', '', '', '2015-04-01 21:42:48', '2015-04-01 21:42:48', '', 74, 'http://localhost/acnew/wp-content/uploads/2015/04/F500Retailer_portfolio_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2015-04-01 21:44:36', '2015-04-01 21:44:36', '<h1>Key Facts</h1>\r\n<b>Locations: </b>America HQ – Stores Worldwide\r\n\r\n<b>Industry: </b>Retail\r\n\r\n<b># engineers supported: </b>1,000\r\n<h2><b>The Word</b></h2>\r\n<blockquote>We reached our ROI before the Agile transformation was even completed. Avenue Code executed where others had failed.</blockquote>\r\n- SVP\r\n\r\n&nbsp;\r\n<h2><b>The Challenge</b></h2>\r\nThe management of smaller companies is a normal part of growth, but ensuring they all mature at the same rate can be extremely complicated. Getting all the companies which operate under one parent company speaking the same language comes with much frustration. Our client had this exact issue when we first met them. There was a handful of challenges that arose from this “synchronous maturity” problem. Let’s start from the top:\r\n\r\n&nbsp;\r\n\r\n<b>General Parity Issues</b>\r\n\r\nThe parent company had a web division [Company A] with an engineering team, but the sister company [Company B] did not. However, these two subsidiaries operated independently of one another, which meant that developing new software to be used by both was too expensive. First, Company A would have to create it, then Company B would try to replicate it with their own IT organization or have to flat out buy it. This software duplication kept the client from progressing technologically. In Company B, IT was essentially non-existent, which made even insignificant changes a headache. In Company A, they had both software development and a website to manage, but no synchronous strategy with their lagging sister company. What they desperately needed was a team of agile experts to transform their organizations into one unified effort.\r\n\r\n&nbsp;\r\n\r\n<b>Financial Remodeling</b>\r\n\r\nResources were unevenly spent due to their original financial model. Before Avenue Code stepped in, engineers were only given financial incentives based on Company A’s website revenue, which left Company B neglected.\r\n\r\n&nbsp;\r\n\r\n<b>Product Development Parity Issues </b>\r\n\r\nMuch like the general parity issue, the product and project managers were only provided for Company A and not Company B. Naturally, they focused all their efforts on just Company A, instead of both of the subsidiaries. Company B was left having to buy the technology they needed, instead of being able to use it jointly.\r\n\r\n&nbsp;\r\n\r\n<b>Absence of an IT Org</b>\r\n\r\nSince only Company A had an IT organization, the technology was only updated and created for that company. This left Company B’s software innovation in the dust.\r\n\r\n<b>The Solution</b>\r\n\r\nSolving the parity problem set off a domino effect between the two subsidiaries. We started with a strategic infrastructure plan. In this plan we created an engineering team for the Company B, which was being neglected by the limited IT structure at the sister company. Now there wouldn’t be the strain of two companies on a team meant to meet the needs of just one company. Similarly, we also designed the developer financial incentives to reflect the success of both the subsidiaries’ website performance combined.\r\n\r\nTo ensure that product development ran smoothly for both companies, we nominated the proper amount of product and project managers for each. After this was accomplished, we unified the software development tools. These tools, paired with their respective program management teams, allowed for quicker software development for both companies.\r\n\r\nWhen companies are a part of a larger organization, it can be a headache to get them operating at the same speed. Luckily, we were able to find the pain points in these subsidiaries and fix them so that each company had the proper team to support the overall needs of the client. The results were incredible. Never underestimate the power of a proper strategic infrastructure plan.\r\n\r\n&nbsp;\r\n<h2><b>Results</b></h2>\r\n<ul>\r\n	<li>Client’s overall IT costs were decreased by $40 million</li>\r\n	<li>Project delivery increased by 300%</li>\r\n	<li>For the company with a new IT organization 60% of IT costs cut</li>\r\n</ul>', 'Fortune 100 Retailer', '', 'publish', 'closed', 'closed', '', 'fortune-100-retailer', '', '', '2015-04-01 21:44:36', '2015-04-01 21:44:36', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=76', 0, 'clients_partners', '', 0),
(77, 1, '2015-04-01 21:45:16', '2015-04-01 21:45:16', '', 'American Eagle', '', 'publish', 'closed', 'closed', '', 'american-eagle', '', '', '2015-04-01 21:45:28', '2015-04-01 21:45:28', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=77', 0, 'clients_partners', '', 0),
(78, 1, '2015-04-01 21:46:07', '2015-04-01 21:46:07', '', 'Macy\'s', '', 'publish', 'closed', 'closed', '', 'macys', '', '', '2015-04-01 21:46:07', '2015-04-01 21:46:07', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=78', 0, 'clients_partners', '', 0),
(79, 1, '2015-04-01 21:47:08', '2015-04-01 21:47:08', '<h2 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 30px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Se Tornando Agile em 6 meses</h2>\r\n<h3 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 24px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Fatos Chaves</h3>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;"><strong>Locais</strong>: Sede nos EUA - lojas por todo o mundo</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;"><strong style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Ramo:</strong> Varejo</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;"><strong style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: bold; font-stretch: inherit; line-height: inherit; vertical-align: baseline;"># engenheiros suportados:</strong> 2000</p>\r\n\r\n<h3 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 24px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">A Palavra</h3>\r\n<blockquote style="box-sizing: border-box; margin: 0px 0px 20px; padding: 10px 20px; border-width: 0px 0px 0px 5px; border-left-style: solid; border-left-color: #eeeeee; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; quotes: none; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">\r\n<p style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Utilizando sua experiência e vasto conhecimento, a Avenue Code me ajudou a me tornar um scrum master melhor nos meus times de Agile, me suportando e mentorando para ser bem sucedido no ambiente Agile, ao mesmo tempo ensinando como treinar outras pessoas. As habilidades de treinamento da Avenue Code são magníficas.</p>\r\n</blockquote>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Tony Goular, Treinador de Agile Senior na Walmart eCommerce</p>\r\n\r\n<h3 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 24px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">O Desafio</h3>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Antes de entrar em contato com a Avenue Code, o Walmart tentou se tornar Agile duas vezes. A primeira vez focou em treinamento, mas infelizmente isto não foi suficiente para que a adoção de Agile acontecesse. Na segunda vez, o Walmart utilizou uma empresa de gestão de histórias. Eles chegaram perto do êxito, mas não conseguiram novamente. Felizmente, na terceira vez, com a ajuda da Avenue Code, eles conseguiram!</p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">O Walmart tinha diversos buracos que precisavam ser preenchidos. O que precisava ser melhorado imediatamente era um sistema de integração contínua, ajuda com o planejamento de histórias, início de projeto e uma razão entre desenvolvimento em QA que funcionasse. Além das correções técnicas, eles também precisavam de uma mudança na cultura. Para que o Agile funcione na cultura, três coisas precisam ser valorizadas:</p>\r\n\r\n<ol style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; list-style: none; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Desejo de mudança - a adaptabilidade é a chave</li>\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Transparência em todos os níveis - não tema a gerência</li>\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Colocação - encurte o ciclo de feedback</li>\r\n</ol>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Nós os ajudamos a trabalhar nesses valores em seus times. Uma vez que foram adotados, a jonada de inovação de software começou!</p>\r\n\r\n<h3 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 24px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">A Jornada</h3>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Para conseguir que todos falassem a mesma língua, os treinamentos foram feitos em todo o mundo. Nenhuma transformação ágil pode ter sucesso sem a adoção integral pela gerência e um compromisso de um amplo horário de treinamento para que todos conseguissem digerir a nova metodologia. Felizmente, todos estavam totalmente investidos na causa. Apenas para garantir que tudo estava transcorrendo bem, também adicionamos um gerente de projeto Agile na mistura. Após todos os pontos críticos serem encontrados e corrigidos, a equipe de engenharia global do Walmart se tornou uma organização ágil em apenas seis meses!</p>\r\n\r\n<h3 style="box-sizing: border-box; margin: 20px 0px 10px; padding: 20px 0px 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 24px; font-style: normal; font-variant: normal; font-weight: 500; font-stretch: inherit; line-height: 1.1; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Resultados</h3>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">Aqui está o que o Walmart alcançou com nossas soluções:</p>\r\n\r\n<ul style="box-sizing: border-box; margin: 0px 0px 10px; padding: 0px; border: 0px; font-family: \'PT Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 18px; font-style: normal; font-variant: normal; font-weight: 300; font-stretch: inherit; line-height: 29.1240005493164px; vertical-align: baseline; list-style: none; color: #000000; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #fafafa;">\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Aumento na tecnologia e entrega de funcionalidades em 100% através do aumento da qualidade das histórias</li>\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Melhoria em 100% das capacidades de coordenação de planejamento em apenas três meses</li>\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Redução no ciclo de feedback</li>\r\n	<li style="box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline;">Todas as práticas de UX/UI foram redefinidas</li>\r\n</ul>', 'Walmart', '', 'publish', 'closed', 'closed', '', 'walmart', '', '', '2015-04-01 21:47:08', '2015-04-01 21:47:08', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=79', 0, 'clients_partners', '', 0),
(80, 1, '2015-04-01 21:43:45', '0000-00-00 00:00:00', '', 'Chef', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-04-01 21:43:45', '2015-04-01 21:43:45', '', 0, 'http://localhost/acnew/?post_type=clients_partners&#038;p=80', 0, 'clients_partners', '', 0),
(81, 1, '2015-04-01 21:44:33', '2015-04-01 21:44:33', '', 'F100Retailer_portfolio_300x400', '', 'inherit', 'open', 'open', '', 'f100retailer_portfolio_300x400', '', '', '2015-04-01 21:44:33', '2015-04-01 21:44:33', '', 76, 'http://localhost/acnew/wp-content/uploads/2015/04/F100Retailer_portfolio_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 1, '2015-04-01 21:45:12', '2015-04-01 21:45:12', '', 'american_eagle_300x400', '', 'inherit', 'open', 'open', '', 'american_eagle_300x400', '', '', '2015-04-01 21:45:12', '2015-04-01 21:45:12', '', 77, 'http://localhost/acnew/wp-content/uploads/2015/04/american_eagle_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(83, 1, '2015-04-01 21:45:59', '2015-04-01 21:45:59', '', 'F150Retailer_portfolio_300x4001', '', 'inherit', 'open', 'open', '', 'f150retailer_portfolio_300x4001', '', '', '2015-04-01 21:45:59', '2015-04-01 21:45:59', '', 78, 'http://localhost/acnew/wp-content/uploads/2015/04/F150Retailer_portfolio_300x4001.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2015-04-01 21:47:06', '2015-04-01 21:47:06', '', 'walmart_300x400', '', 'inherit', 'open', 'open', '', 'walmart_300x400', '', '', '2015-04-01 21:47:06', '2015-04-01 21:47:06', '', 79, 'http://localhost/acnew/wp-content/uploads/2015/04/walmart_300x400.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2015-04-02 17:11:31', '2015-04-02 17:11:31', '', 'home-photo', '', 'inherit', 'open', 'open', '', 'home-photo', '', '', '2015-04-02 17:11:31', '2015-04-02 17:11:31', '', 5, 'http://localhost/acnew/wp-content/uploads/2015/03/home-photo.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 1, '2015-04-02 17:11:39', '2015-04-02 17:11:39', '', 'home_landing_SaoPaulo', '', 'inherit', 'open', 'open', '', 'home_landing_saopaulo', '', '', '2015-04-02 17:11:39', '2015-04-02 17:11:39', '', 5, 'http://localhost/acnew/wp-content/uploads/2015/03/home_landing_SaoPaulo.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2015-04-02 17:11:46', '2015-04-02 17:11:46', '', 'home_landing_BeloHorizonte', '', 'inherit', 'open', 'open', '', 'home_landing_belohorizonte', '', '', '2015-04-02 17:11:46', '2015-04-02 17:11:46', '', 5, 'http://localhost/acnew/wp-content/uploads/2015/03/home_landing_BeloHorizonte.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2015-04-02 18:38:38', '2015-04-02 18:38:38', '', 'Header Cover Texts', '', 'publish', 'closed', 'closed', '', 'header-cover-texts', '', '', '2015-04-02 18:38:38', '2015-04-02 18:38:38', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=88', 0, 'wck-meta-box', '', 0),
(89, 1, '2015-04-07 20:21:55', '2015-04-07 20:21:55', '', 'Services - Header', '', 'publish', 'closed', 'closed', '', 'management-consulting-header', '', '', '2015-04-09 20:39:05', '2015-04-09 20:39:05', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=89', 0, 'wck-meta-box', '', 0),
(90, 1, '2015-04-07 20:24:24', '2015-04-07 20:24:24', '', 'Services - Body', '', 'publish', 'closed', 'closed', '', 'management-consulting-body', '', '', '2015-04-08 21:24:06', '2015-04-08 21:24:06', '', 0, 'http://localhost/acnew/?post_type=wck-meta-box&#038;p=90', 0, 'wck-meta-box', '', 0),
(91, 1, '2015-04-07 20:28:11', '2015-04-07 20:28:11', '', 'omnichannel', '', 'inherit', 'open', 'open', '', 'omnichannel', '', '', '2015-04-07 20:28:11', '2015-04-07 20:28:11', '', 39, 'http://localhost/acnew/wp-content/uploads/2015/03/omnichannel.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2015-04-07 20:29:15', '2015-04-07 20:29:15', '', 'tech_organization', '', 'inherit', 'open', 'open', '', 'tech_organization', '', '', '2015-04-07 20:29:15', '2015-04-07 20:29:15', '', 39, 'http://localhost/acnew/wp-content/uploads/2015/03/tech_organization.jpg', 0, 'attachment', 'image/jpeg', 0),
(93, 1, '2015-04-07 20:29:44', '2015-04-07 20:29:44', '', 'technology', '', 'inherit', 'open', 'open', '', 'technology', '', '', '2015-04-07 20:29:44', '2015-04-07 20:29:44', '', 39, 'http://localhost/acnew/wp-content/uploads/2015/03/technology.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2015-04-07 20:30:05', '2015-04-07 20:30:05', '', 'process', '', 'inherit', 'open', 'open', '', 'process', '', '', '2015-04-07 20:30:05', '2015-04-07 20:30:05', '', 39, 'http://localhost/acnew/wp-content/uploads/2015/03/process.jpg', 0, 'attachment', 'image/jpeg', 0),
(95, 1, '2015-04-07 21:25:16', '2015-04-07 21:25:16', '', 'light_house', '', 'inherit', 'open', 'open', '', 'light_house', '', '', '2015-04-07 21:25:16', '2015-04-07 21:25:16', '', 39, 'http://localhost/acnew/wp-content/uploads/2015/03/light_house.png', 0, 'attachment', 'image/png', 0),
(96, 1, '2015-04-08 20:39:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-04-08 20:39:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/acnew/?p=96', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(97, 1, '2015-04-08 20:51:53', '2015-04-08 20:51:53', '', 'Management Consulting', '', 'inherit', 'open', 'open', '', '39-autosave-v1', '', '', '2015-04-08 20:51:53', '2015-04-08 20:51:53', '', 39, 'http://localhost/acnew/39-autosave-v1/', 0, 'revision', '', 0),
(98, 1, '2015-04-08 21:09:10', '2015-04-08 21:09:10', '', 'services_program_and_project', '', 'inherit', 'open', 'open', '', 'services_program_and_project', '', '', '2015-04-08 21:09:10', '2015-04-08 21:09:10', '', 41, 'http://localhost/acnew/wp-content/uploads/2015/03/services_program_and_project.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2015-04-08 21:09:35', '2015-04-08 21:09:35', '', 'services_product_management', '', 'inherit', 'open', 'open', '', 'services_product_management', '', '', '2015-04-08 21:09:35', '2015-04-08 21:09:35', '', 41, 'http://localhost/acnew/wp-content/uploads/2015/03/services_product_management.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2015-04-08 21:09:58', '2015-04-08 21:09:58', '', 'services_end_to_end', '', 'inherit', 'open', 'open', '', 'services_end_to_end', '', '', '2015-04-08 21:09:58', '2015-04-08 21:09:58', '', 41, 'http://localhost/acnew/wp-content/uploads/2015/03/services_end_to_end.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 1, '2015-04-08 21:13:07', '2015-04-08 21:13:07', '', 'services_proof_of_concept', '', 'inherit', 'open', 'open', '', 'services_proof_of_concept', '', '', '2015-04-08 21:13:07', '2015-04-08 21:13:07', '', 41, 'http://localhost/acnew/wp-content/uploads/2015/03/services_proof_of_concept.jpg', 0, 'attachment', 'image/jpeg', 0),
(102, 1, '2015-04-08 21:13:35', '2015-04-08 21:13:35', '', 'services_agile', '', 'inherit', 'open', 'open', '', 'services_agile', '', '', '2015-04-08 21:13:35', '2015-04-08 21:13:35', '', 41, 'http://localhost/acnew/wp-content/uploads/2015/03/services_agile.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2015-04-08 21:27:09', '2015-04-08 21:27:09', '', 'services_engineering_professionals', '', 'inherit', 'open', 'open', '', 'services_engineering_professionals', '', '', '2015-04-08 21:27:09', '2015-04-08 21:27:09', '', 43, 'http://localhost/acnew/wp-content/uploads/2015/03/services_engineering_professionals.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2015-04-08 21:27:33', '2015-04-08 21:27:33', '', 'services_agile_professionals', '', 'inherit', 'open', 'open', '', 'services_agile_professionals', '', '', '2015-04-08 21:27:33', '2015-04-08 21:27:33', '', 43, 'http://localhost/acnew/wp-content/uploads/2015/03/services_agile_professionals.jpg', 0, 'attachment', 'image/jpeg', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(1, 4, 0),
(1, 5, 0),
(5, 3, 0),
(7, 3, 0),
(8, 3, 0),
(8, 5, 0),
(8, 7, 0),
(9, 3, 0),
(13, 3, 0),
(14, 3, 0),
(24, 2, 0),
(25, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(29, 2, 0),
(39, 3, 0),
(41, 3, 0),
(43, 3, 0),
(45, 3, 0),
(71, 3, 0),
(73, 3, 0),
(75, 3, 0),
(81, 3, 0),
(82, 3, 0),
(83, 3, 0),
(84, 3, 0),
(85, 3, 0),
(86, 3, 0),
(87, 3, 0),
(91, 3, 0),
(92, 3, 0),
(93, 3, 0),
(94, 3, 0),
(95, 3, 0),
(96, 3, 0),
(98, 3, 0),
(99, 3, 0),
(100, 3, 0),
(101, 3, 0),
(102, 3, 0),
(103, 3, 0),
(104, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 6),
(3, 3, 'language', 'a:2:{s:6:"locale";s:5:"en_US";s:3:"rtl";s:1:"0";}', 0, 33),
(4, 4, 'term_language', '', 0, 1),
(5, 5, 'term_translations', 'a:2:{s:2:"en";i:1;s:2:"pt";i:8;}', 0, 2),
(6, 6, 'language', 'a:2:{s:6:"locale";s:5:"pt_BR";s:3:"rtl";s:1:"0";}', 0, 0),
(7, 7, 'term_language', '', 0, 1),
(8, 8, 'category', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'menu_en', 'menu_en', 0),
(3, 'English', 'en', 0),
(4, 'English', 'pll_en', 0),
(5, 'pll_55198b7115fc0', 'pll_55198b7115fc0', 0),
(6, 'Português', 'pt', 0),
(7, 'Português', 'pll_pt', 0),
(8, 'Uncategorized', 'uncategorized-pt', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'acadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:3:{s:64:"2297296417483abcf62dee505352912fdd673a0a22a36646d1bd1c81d7f8149b";a:4:{s:10:"expiration";i:1428616464;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:105:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36";s:5:"login";i:1428443664;}s:64:"5d3b94c252cbcfa59d9c5943b0cf34eb114e194774ab719d15910db2b2d3c38e";a:4:{s:10:"expiration";i:1428698352;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:105:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36";s:5:"login";i:1428525552;}s:64:"f3f5f4d0fe48a1f9a4760be45c30b0b28d64f4610b36511c597d7ba5b3ad13a6";a:4:{s:10:"expiration";i:1428784587;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:105:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36";s:5:"login";i:1428611787;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '96'),
(16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}'),
(18, 1, 'nav_menu_recently_edited', '2'),
(19, 1, 'wp_media_library_mode', 'list'),
(20, 1, 'meta-box-order_page', 'a:3:{s:4:"side";s:43:"ml_box,submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:87:"services-header,services-body,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(21, 1, 'screen_layout_page', '2'),
(22, 1, 'wp_user-settings', 'libraryContent=browse'),
(23, 1, 'wp_user-settings-time', '1428441915') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'acadmin', '$P$BRd34GeBnzK4haJqJ3jTrHWIGKaVyW/', 'acadmin', 'teste@teste.com', '', '2015-03-23 16:32:07', '', 0, 'acadmin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

